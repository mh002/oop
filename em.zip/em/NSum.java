/*
 *  Name: 
 *  Roll Number:
 *  KTU ID:
 */

// Use a class name which is matching to the file name.
import java.util.Scanner; // Import the Scanner class

class NSum {
  public static void main(String[] args) {
    int n, y, sum=0;
    Scanner myObj = new Scanner(System.in); // Create a Scanner object
    System.out.println("Enter the value of N:");
    n = myObj.nextInt(); // Read user input
    
    
    System.out.println("Enter the numbers:");
    for(int i=0;i<n;i++){
    y = myObj.nextInt();// Read n numbers in a for loop
    sum=sum+y;// calculate the sum of all numbers
    }
   

    //Print the sum
    System.out.println("Sum is: " + sum); // Print the sum
  }
} 