import java.util.Scanner;
public class QuickSort
{
    String names[];
    int length;
    void exchangeNames(int i, int j)
    {
    String temp = this.names[i];
    this.names[i] = this.names[j];
    this.names[j] = temp;
    }
    void quick_sort(int left,int right)
    {
    String pivot=this.names[(left+right)/2];
    int i=left;
    int j=right;
    while(i<=j)
    {
    while(this.names[i].compareToIgnoreCase(pivot)<0)
    i++;
    while(this.names[j].compareToIgnoreCase(pivot)>0)
    j--;
    if(i<=j)
    {
    exchangeNames(i,j);
    i++;
    j--;
    }}
    if(left<j)
    quick_sort(left,j);
    if(i<right)
    quick_sort(i,right);
    }
    void sort(String array[])
    {
    if(array==null || array.length==0)
    return;
    this.names=array;
    this.length=array.length;
    quick_sort(0,length-1);
    }
public static void main(String args[])
{
QuickSort obj=new QuickSort();
Scanner sc=new Scanner(System.in);
Scanner s1=new Scanner(System.in);
System.out.println("enter number of names");
int n=sc.nextInt();
System.out.println("enter the names");
String[] nameList=new String[n];
for(int i=0;i<nameList.length;++i)
nameList[i]=s1.nextLine();
obj.sort(nameList);
System.out.println("\nsorted\n");
for(int i=0;i<n;++i)
System.out.print(nameList[i]+"\n");
}}
