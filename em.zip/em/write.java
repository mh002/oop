import java.util.*;
import java.io.*;

public class write{
     public static void main(String[] args) {
         
        try {
            File fobj= new File("IDK19CS008.txt");
            if(fobj.createNewFile())
            {
                System.out.println(" New file is created.");
            }
            else{
                System.out.println(" File already exists.");
            }
        } catch (IOException e) 
        { System.out.println("Error occured while writing file");}
        try {
            FileWriter wobj=new FileWriter("IDK19CS008.txt");
            wobj.write("Akshay mr\nKottappadi\nMalappuram");
            wobj.close();
        }
        catch (IOException e)
        { System.out.println("Error occured while writing file");}
        try {
            File fobj= new File("IDK19CS008.txt");
            Scanner robj=new Scanner(fobj);
            while(robj.hasNextLine()){
                String data = robj.nextLine();
                System.out.println(data);
            }}
        catch (FileNotFoundException e) {
            System.out.println("Error occured while reading file");
        }
    }
}
