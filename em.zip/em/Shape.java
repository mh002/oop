import java.util.Scanner;

class Shape{
    public static void main(String args[])
    {
       String shape;
       Scanner s=new Scanner(System.in);
       //System.out.println("Enter the shape name: ");
       shape=s.nextLine();
       if(shape.equals("RECTANGLE"))
       {
        int l,b;
        //System.out.println("Enter length: ");
        l = s.nextInt();
       // System.out.println("Enter breadth: ");
        b = s.nextInt();
        Rectangle rectangle= new Rectangle();
        rectangle.displayArea(l,b);
       }
       else if(shape.equals("CIRCLE"))
       {
        int r;
        //System.out.println("Enter radius");
        r=s.nextInt();
        Circle circle=new Circle();
        circle.displayArea(r);
       }
        else if(shape.equals("TRIANGLE"))
       {
        int b,h;
        //System.out.println("Enter base");
        b=s.nextInt();
        //System.out.println("Enter hieght");
        h=s.nextInt();
        Triangle triangle=new Triangle();
        triangle.displayArea(b,h);
       }
    }
    
}

class Rectangle
{
    void displayArea(int l,int b)
    {
        int area=l*b;
        System.out.println(area);
    }
}

class Circle
{
    void displayArea(int r)
    {  
        int area=(22*r*r)/7;
        System.out.println(area);
    }
}

class Triangle
{
    void displayArea(int b,int h)
    {  
        int area=(b*h)/2;
        System.out.println(area);
    }
}