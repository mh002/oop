import java.util.*;
import java.io.*;

public class read{
    public static void main(String[] args) 
    {
        char array[]=new char[100];
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the file to read");
        String file=sc.nextLine();
        try {
        FileReader robj=new FileReader(file);
        robj.read(array);
        robj.close();
        System.out.println(array);}
        catch (IOException e) {
        System.out.println("Could not find the file");}
        try{
        FileWriter wobj=new FileWriter("copy.txt");
        int i=0;
        while(array[i]!='\0')
        {
        wobj.write(array[i]);
        ++i;
        }
        wobj.close();
        System.out.println("\n\tCOPIED SUCCESSFULLY TO copy.txt");
        }
        catch(IOException e)
        {
        System.out.println("Error while copying file");}
    }
    
}
