import java.lang.Math;

class shapes{
  double Area(int x,int y){
      return x*y;
  }
  double Area(int r){
    return Math.PI*r*r;
  }
  double Area(int x,int y,int z){
      double s=(x+y+z)/2;
      double sqa=(s*(s-x)*(s-y)*(s-z));
       return Math.sqrt(sqa);
  }
}

class test{
    public static void main(String[] args) {
        shapes s1=new shapes();
        System.out.println("Area of Rectangle ="+s1.Area(3,4));
        System.out.println("Area of Circle ="+s1.Area(3));
        System.out.println("Area of Triangle ="+s1.Area(3, 4, 5));
    }
}
