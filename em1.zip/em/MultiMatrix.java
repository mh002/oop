/*
 *  Name: Akshay Mr
 *  Roll Number: 08
 *  KTU ID: IDK19CS008
 */

// Use a class name which is matching to the file name.
import java.util.Scanner; // Import the Scanner class
class MultiMatrix{
    public static void main(String args[])
    {
        int i,j,k,r1,c1,r2,c2;
        Scanner scan =new Scanner(System.in);
        System.out.println("Enter the number of rows and columns of first matrix ");
        r1=scan.nextInt();
        c1=scan.nextInt();
        int a1[][] = new int[r1][c1];
        System.out.println("Enter elements of first matrix");
        for(i=0;i<r1;i++)    
        {    
            for(j=0;j<c1;j++)    
            {    
                a1[i][j]=scan.nextInt();
                System.out.print(" ");
            }    
        }
        System.out.println("Enter the number of rows and columns of second matrix");
        r2=scan.nextInt();
        c2=scan.nextInt();
         int a2[][] = new int[r2][c2];
         if(c1 !=r2)
         {
             System.out.println("x");
         }
         else
         {
             
         
        System.out.println("Enter elements of second matrix ");
        for(i=0;i<r2;i++)    
        {    
            for(j=0;j<c2;j++)    
            {    
                a2[i][j]= scan.nextInt();
                System.out.println(" ");
            }    
        } 
        System.out.println("Product of the matrices:  ");
        int multi[][] = new int [r1][c2];
        for( i = 0; i < r1; i++) 
        {
            for ( j = 0; j < c2; j++)
            {
                for ( k = 0; k < c1; k++)
                {
                    multi[i][j] += a1[i][k] * a2[k][j];
                }
            }
        }
        for(i=0;i<r1;i++)
        {
            for(j=0;j<c2;j++)
            {
                System.out.println(multi[i][j]+" ");
            }
        }
        
         }
        
    }
}    
        