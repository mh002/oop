import java.util.Scanner;
class DoubleLList
{
    class node
    {
    int data;
    node left,right;
    public node(int data)
    {
    this.data=data;
}}
node head,tail=null;
public void addNode(int data)
{
    node newnode=new node(data);
    if(head==null)
    {
    head=tail=newnode;
    head.left=null;
    tail.right=null;
}
else
{
    tail.right=newnode;
    newnode.left=tail;
    tail=newnode;
    tail.right=null;
}}

public void display()
{
    node current=head;
    if(head==null)
    {
    System.out.println("list is empty");
    return;
}
while(current!=null)
{
    System.out.print(current.data+" ");
    current=current.right;
}
System.out.println();
}
public void delete(int key)
{
    node prev=head,ptr=head;
    if(head==null)
    {
    System.out.println("Linkedlist empty");
    return;
    }
    if(head.data==key) 
    {
    if(head.right!=null) 
    {
    head.right.left=null;
    head=head.right;
    return;
    }
    else 
    {
    head=null;
    return;
    }
    }
    else if(head.data!=key && head.right==null) 
    { System.out.println(key+" not found");
    return; }
    while(ptr.right!=null && ptr.data!=key)
    {
    prev=ptr;
    ptr=ptr.right;
    }
    if(ptr.data==key)
    {
    prev.right=prev.right.right;
    if(prev.right!=null)
    prev.right.left=prev;
    else
    tail=prev;
    }
    else
    System.out.println(key+" not found");
}
public static void main(String args[])
{
    DoubleLList LL=new DoubleLList();
    Scanner sc=new Scanner(System.in);
    int choice=1,data;
    while(choice>=1 && choice<=3)
    {
    System.out.println("1 Insert\n2 Delete\n3 Display\n4 exit");
    choice=sc.nextInt();
    if(choice==1)
    {
    System.out.println("enter  element");
    data=sc.nextInt();
    LL.addNode(data);
    }
    else if(choice==2)
    {
    System.out.println("Enter element to be deleted");
    data=sc.nextInt();
    LL.delete(data);
    }
    else if(choice==3)
    LL.display();
}}}