/*
 *  Name: Akshay Mr
 *  Roll Number: 08
 *  KTU ID: IDK19CS008
 */

// Use a class name which is matching to the file name.
import java.util.Scanner; // Import the Scanner class
class Transpose{
    public static void main(String args[])
    {
        int i,j;
        Scanner scan =new Scanner(System.in);
        int column= scan.nextInt();
        int row= scan.nextInt();
        int matrix[][]=new int[row][column];
        for(i=0;i<row;i++)
        {
            for(j=0;j<column;j++)
            {
                matrix[i][j]=scan.nextInt();
                
            }
        }
        for(i=0;i<column;i++)
        {
            for(j=0;j<row;j++)
            {
                System.out.print(matrix[j][i]+" ");
            }
            System.out.println(" ");
        }
    }
}