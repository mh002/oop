/*
 *  Name: Akshay mr
 *  Roll Number: 08
 *  KTU ID:IDK19CS008
 */

// Use a class name which is matching to the file name.
import java.util.Scanner; // Import the Scanner class
public class TestPrime {

    public static void main(String[] args) {

        int num = 0,i;
		Scanner myObj = new Scanner(System.in); // Create a Scanner object
		num = myObj.nextInt(); // Read user input
        for(i=2;i<=num/2;i++)
        {
            if (num%i==0)
            {
                break;
            }
        }
        if(i>num/2)//if  prime
            System.out.println("PRIME");
        else//else
            System.out.println("NONPRIME");
    }
}